const makeCard = (node, status)=>{

    const mainDiv = document.createElement("div");
    mainDiv.classList.add("card", "w-100", "shadow-lg", "p-3", "mb-3", "bg-body-tertiary", "rounded");
    
    const bodyDiv = document.createElement("div");
    bodyDiv.classList.add("card-body");
    
    const title = document.createElement("h5");
    title.classList.add("card-title", "text-start");
    title.innerText = node["category"];
    
    const texts = [document.createElement("p"), document.createElement("p"), document.createElement("p")]
    texts.forEach(text => {
        text.classList.add("card-text", "text-start");
    });
    texts[0].innerText = node["todo"];
    texts[1].innerText = "Due date: " + node["dueDate"];
    texts[2].innerText = "Priority: " + node["priority"];
    
    const btnDiv = document.createElement("div");
    btnDiv.classList.add("d-flex", "justify-content-start");
    
    const btnEdit = document.createElement("button");
    btnEdit.classList.add("btn", "btn-outline-primary");
    btnEdit.innerText = "Edit";
    
    const btnDelete = document.createElement("button");
    btnDelete.classList.add("btn", "btn-outline-danger", "ms-3");
    btnDelete.innerText= "Delete";
    
    btnDiv.append(btnEdit, btnDelete);
    
    bodyDiv.append(title, texts[0], texts[1], texts[2], btnDiv);
    mainDiv.appendChild(bodyDiv);
    
    document.getElementById(status).appendChild(mainDiv);
    };


const GetTasks = async (status) => {
    let url = "http://localhost:3000/todos?status=" + status;
    
    const response = await fetch(url, {
        method:"GET",
        headers:{
            "Content-Type": "application/json"
        }
    });

    const result = await response.json();
    result.forEach(node => {
        makeCard(node, status.toLowerCase());
    });
};

document.getElementById("logout").onclick = () => {
    window.localStorage.setItem("user", 0);
};

export default{
    GetTasks
}