if(window.localStorage.getItem("user") === "0")
{
    alert("You have to login first");
    window.location.href="../LoginPage/loginIndex.html";
}

import functions from "./function.js";


functions.GetTasks("TODO");
functions.GetTasks("INPROGRESS");
functions.GetTasks("DONE");