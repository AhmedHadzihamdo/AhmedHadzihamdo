const UsernameInput = document.getElementById('UsernameInput');
const PasswordInput = document.getElementById('PasswordInput');
const Errors = document.getElementById('Errors');
const LoginBut = document.getElementById('LoginButton');
const NotValid = document.getElementById('NotValid');

function ValidacijaUsername() {

    const username = UsernameInput.value;

    if (!username) {
        Errors.classList.remove("hide");
        return false;
    }
    Errors.classList.add("hide");
    return true;
}

function ValidacijaPassword() {
    const password = PasswordInput.value;

    if (!password) {
        Errors.classList.remove("hide");
        return false;
    }
    else {
        Errors.classList.add("hide");
        return true;
    }
}

LoginBut.onclick = async() => {
    const url = 'http://localhost:3000/register';
    if (ValidacijaUsername() && ValidacijaPassword()) {
        Errors.classList.add("hide");
        const params = new URLSearchParams({
            username: UsernameInput.value,
            password: PasswordInput.value
        });
        const options = {
            method: 'POST',
            body: params,
            headers: {
                'Content-Type': "application/x-www-form-urlencoded",
                Connection: "keep-alive",
                Accept: "*"
            }
        };
        try {
            const response = await fetch(url, options);
            const result = await response

            if (result.ok) {
                window.location.href = "homepage.html";
            } 
            else {
                console.log("Error");
            }
            } 
            catch(err) {
                console.log(err);
                return;
                }
    }
    else {
        NotValid.classList.remove("hide");
    }
}



// const login = 'http://localhost:3000/login';

// fetch(login, {
//     method: "POST",
//     headers: {
//         Accept: "application/json, text/plain, */*",
//         "Content-Type": "application/json",
//     },
//     body: JSON.stringify({
//         username: UsernameInput.value,
//         password: PasswordInput.value
//     }),
// })
//     .then((data) => console.log(data))
//     .catch((err) => {
//         console.log(err);
//     });