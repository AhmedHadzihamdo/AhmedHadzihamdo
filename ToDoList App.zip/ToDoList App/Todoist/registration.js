const UsernameInput = document.getElementById('UsernameInput');
const NameInput = document.getElementById('NameInput');
const LastnameInput = document.getElementById('LastNameInput');
const PasswordInput = document.getElementById('PasswordInput');
const RegistrationButt = document.getElementById('RegisterButton');
const Errors = document.getElementById('Errors');

function ValidacijaUsername() {

    const username = UsernameInput.value;

    if (!username) {
        Errors.classList.remove("hide");
        return false;
    }
    Errors.classList.add("hide");
    return true;
}

function ValidacijaPassword() {
    const password = PasswordInput.value;

    if (!password) {
        Errors.classList.remove("hide");
        return false;
    }
    else {
        Errors.classList.add("hide");
        return true;
    }
}
function ValidacijaName() {

    const name = NameInput.value;

    if (!name) {
        Errors.classList.remove("hide");
        return false;
    }
    Errors.classList.add("hide");
    return true;
}
function ValidacijaLastName() {

    const lastname = LastnameInput.value;

    if (!lastname) {
        Errors.classList.remove("hide");
        return false;
    }
    Errors.classList.add("hide");
    return true;
}
RegistrationButt.onclick = async () => {
        const url = 'http://localhost:3000/register';
        if(ValidacijaName() && ValidacijaLastName() && ValidacijaUsername() && ValidacijaPassword())
        {
            Errors.classList.add("hide");
            const params = new URLSearchParams({
                firstName: NameInput.value,
                lastName: LastnameInput.value,
                username: UsernameInput.value,
                password: PasswordInput.value
            });
            const options = {
                method: 'POST',
                body: params,
                headers: {
                    'Content-Type': "application/x-www-form-urlencoded",
                    Connection: "keep-alive",
                    Accept: "*"
                }
            };
            try {
                const response = await fetch(url, options);
                const result = await response
    
                if (result.ok) {
                    window.location.href = "index.html";
                } 
                else {
                    console.log("Error");
                }
                } 
                catch(err) {
                    console.log(err);
                    return;
                    }
        }
        else {
            Errors.classList.remove("hide");
        }
};
/*

*/