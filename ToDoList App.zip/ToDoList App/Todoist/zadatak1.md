***LOGIN***

- Prikazati korisniku login stranicu kao sa slike `login`
- Na formi je potrebno implementirati validaciju, tako da su oba polja obavezna (slika `loginError`)
- Podaci o ruti za login su:
    - http://localhost:3000/login
    - metoda je POST
    - parametri su username i password (saljete ih kao body). Koristiti `new URLSearchParams`
    - Kao headere je potrebno setovato slijedece:
    ```
     "Content-Type": "application/x-www-form-urlencoded",
      Connection: "keep-alive",
      Accept: "*",
    ```
- Ukoliko su login podaci pogrešni korisniku je potrebno prikazati odgovarajuću poruku (slika `loginFailed`)
- Ukoliko su login podaci validni, te je ruta vratila status 200, korisnika je potrebno redirektati na početnu stranicu
- Na login page-u također možete primjetiti `Don't have account yet? Register here`. Klikom na `here` treba korisnika da se redirekta na stranicu za registraciju (slika registration)

***REGISTRACIJA***

- Potrebno je odraditi validaciju forme, tako da su sva polja obavezna (slika `registrationError`)
- Podaci o ruti za registraciju su:
    - http://localhost:3000/register
    - metoda je POST
    - kao body šaljete (koristiti URLSearchParams)
    ```
        {
            username: string,
            password: string,
            firstName: string,
            lastName: string,
        }
    ```
    - headers isti kao kod logina
- Ukoliko je registracija uspješno prošla, korisnika redirektati na login page kako bi se mogao logirati u aplikaciju
